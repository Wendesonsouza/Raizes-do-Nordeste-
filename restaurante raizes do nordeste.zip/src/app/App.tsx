import { useState } from 'react';
import { MenuSection } from './components/MenuSection';
import { ClientRegistration, Client } from './components/ClientRegistration';
import { ManagementPanel } from './components/ManagementPanel';
import { UtensilsCrossed, Users, BarChart3 } from 'lucide-react';

interface MenuItem {
  id: string;
  name: string;
  size: string;
  price: number;
  description: string;
}

interface Order {
  id: string;
  clientName: string;
  items: Array<{ name: string; quantity: number; price: number }>;
  total: number;
  date: string;
  status: 'pending' | 'completed';
}

type Section = 'menu' | 'clients' | 'management';

export default function App() {
  const [activeSection, setActiveSection] = useState<Section>('menu');
  const [clients, setClients] = useState<Client[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  const handleAddClient = (clientData: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = {
      ...clientData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setClients(prev => [...prev, newClient]);
  };

  const handleAddToCart = (item: MenuItem, quantity: number) => {
    const newOrder: Order = {
      id: Date.now().toString(),
      clientName: 'Cliente Balcão',
      items: [{
        name: item.name,
        quantity,
        price: item.price
      }],
      total: item.price * quantity,
      date: new Date().toISOString(),
      status: 'pending'
    };
    setOrders(prev => [...prev, newOrder]);
  };

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b border-border bg-background sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex items-center justify-between h-16">
            <h2>Raízes do Sertão</h2>

            <div className="flex gap-1">
              <button
                onClick={() => setActiveSection('menu')}
                className={`px-4 py-2 flex items-center gap-2 ${
                  activeSection === 'menu'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-foreground hover:bg-muted'
                }`}
              >
                <UtensilsCrossed size={18} />
                Cardápio
              </button>

              <button
                onClick={() => setActiveSection('clients')}
                className={`px-4 py-2 flex items-center gap-2 ${
                  activeSection === 'clients'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-foreground hover:bg-muted'
                }`}
              >
                <Users size={18} />
                Clientes
              </button>

              <button
                onClick={() => setActiveSection('management')}
                className={`px-4 py-2 flex items-center gap-2 ${
                  activeSection === 'management'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-foreground hover:bg-muted'
                }`}
              >
                <BarChart3 size={18} />
                Gerenciamento
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main>
        {activeSection === 'menu' && (
          <MenuSection onAddToCart={handleAddToCart} />
        )}

        {activeSection === 'clients' && (
          <ClientRegistration
            onAddClient={handleAddClient}
            clients={clients}
          />
        )}

        {activeSection === 'management' && (
          <ManagementPanel
            clients={clients}
            orders={orders}
          />
        )}
      </main>
    </div>
  );
}