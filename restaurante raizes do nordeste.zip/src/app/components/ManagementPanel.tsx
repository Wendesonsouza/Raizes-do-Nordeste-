import { Client } from './ClientRegistration';
import { DollarSign, ShoppingBag, Users, CheckCircle, Clock, Shield } from 'lucide-react';

interface Order {
  id: string;
  clientName: string;
  items: Array<{ name: string; quantity: number; price: number }>;
  total: number;
  date: string;
  status: 'pending' | 'completed';
}

interface ManagementPanelProps {
  clients: Client[];
  orders: Order[];
}

export function ManagementPanel({ clients, orders }: ManagementPanelProps) {
  const pendingOrders = orders.filter(o => o.status === 'pending');
  const completedOrders = orders.filter(o => o.status === 'completed');
  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);

  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <h1>Painel de Gerenciamento</h1>
        <p className="text-muted-foreground mt-2">
          Visão geral do restaurante
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="border border-border rounded-lg p-6 bg-card">
          <div className="flex items-center justify-between mb-2">
            <p className="text-muted-foreground">Total de Clientes</p>
            <Users size={24} className="text-primary" />
          </div>
          <p className="text-3xl">{clients.length}</p>
        </div>

        <div className="border border-border rounded-lg p-6 bg-card">
          <div className="flex items-center justify-between mb-2">
            <p className="text-muted-foreground">Pedidos Pendentes</p>
            <Clock size={24} className="text-orange-500" />
          </div>
          <p className="text-3xl">{pendingOrders.length}</p>
        </div>

        <div className="border border-border rounded-lg p-6 bg-card">
          <div className="flex items-center justify-between mb-2">
            <p className="text-muted-foreground">Pedidos Finalizados</p>
            <CheckCircle size={24} className="text-green-500" />
          </div>
          <p className="text-3xl">{completedOrders.length}</p>
        </div>

        <div className="border border-border rounded-lg p-6 bg-card">
          <div className="flex items-center justify-between mb-2">
            <p className="text-muted-foreground">Receita Total</p>
            <DollarSign size={24} className="text-green-600" />
          </div>
          <p className="text-3xl">R$ {totalRevenue.toFixed(2)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <div className="mb-4 flex items-center gap-2">
            <ShoppingBag size={24} />
            <h2>Pedidos Recentes</h2>
          </div>

          <div className="space-y-4 max-h-[500px] overflow-y-auto">
            {orders.length === 0 ? (
              <div className="border border-border rounded-lg p-8 bg-card text-center">
                <ShoppingBag size={48} className="mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">
                  Nenhum pedido registrado ainda
                </p>
              </div>
            ) : (
              orders.map((order) => (
                <div
                  key={order.id}
                  className="border border-border rounded-lg p-4 bg-card"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4>{order.clientName}</h4>
                      <p className="text-muted-foreground">
                        {new Date(order.date).toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <span
                      className={`px-3 py-1 rounded text-sm ${
                        order.status === 'completed'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-orange-100 text-orange-800'
                      }`}
                    >
                      {order.status === 'completed' ? 'Finalizado' : 'Pendente'}
                    </span>
                  </div>

                  <div className="mb-2">
                    {order.items.map((item, idx) => (
                      <p key={idx} className="text-muted-foreground">
                        {item.quantity}x {item.name} - R$ {(item.price * item.quantity).toFixed(2)}
                      </p>
                    ))}
                  </div>

                  <div className="border-t border-border pt-2 mt-2">
                    <p>Total: R$ {order.total.toFixed(2)}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div>
          <div className="mb-4 flex items-center gap-2">
            <Users size={24} />
            <h2>Lista de Clientes</h2>
          </div>

          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            {clients.length === 0 ? (
              <div className="border border-border rounded-lg p-8 bg-card text-center">
                <Users size={48} className="mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">
                  Nenhum cliente cadastrado ainda
                </p>
              </div>
            ) : (
              clients.map((client) => (
                <div
                  key={client.id}
                  className="border border-border rounded-lg p-4 bg-card"
                >
                  <div className="flex items-start justify-between mb-1">
                    <h4>{client.name}</h4>
                    {client.isAdmin && (
                      <span className="flex items-center gap-1 px-2 py-1 bg-primary text-primary-foreground rounded text-sm">
                        <Shield size={12} />
                        Admin
                      </span>
                    )}
                  </div>
                  <p className="text-muted-foreground">📱 {client.phone}</p>
                  {client.area && (
                    <p className="text-muted-foreground">🗺️ {client.area}</p>
                  )}
                  {client.address && (
                    <p className="text-muted-foreground">📍 {client.address}</p>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
