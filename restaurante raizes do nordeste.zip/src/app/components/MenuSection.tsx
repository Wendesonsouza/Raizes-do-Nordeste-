import { useState } from 'react';
import { ShoppingCart } from 'lucide-react';

interface MenuItem {
  id: string;
  name: string;
  size: string;
  price: number;
  description: string;
  weight: string;
}

interface MenuSectionProps {
  onAddToCart: (item: MenuItem, quantity: number) => void;
}

export function MenuSection({ onAddToCart }: MenuSectionProps) {
  const [quantities, setQuantities] = useState<Record<string, number>>({});

  const menuItems: MenuItem[] = [
    {
      id: '1',
      name: 'Cuscuz Pequeno',
      size: 'Pequeno',
      weight: '150g',
      price: 8.90,
      description: 'Perfeito para um lanche rápido'
    },
    {
      id: '2',
      name: 'Cuscuz Médio',
      size: 'Médio',
      weight: '300g',
      price: 15.90,
      description: 'Porção individual ideal'
    },
    {
      id: '3',
      name: 'Cuscuz Grande',
      size: 'Grande',
      weight: '500g',
      price: 24.90,
      description: 'Para quem tem bom apetite'
    },
    {
      id: '4',
      name: 'Cuscuz Família',
      size: 'Família',
      weight: '1kg',
      price: 42.90,
      description: 'Serve até 4 pessoas'
    }
  ];

  const handleQuantityChange = (itemId: string, value: number) => {
    setQuantities(prev => ({
      ...prev,
      [itemId]: Math.max(1, value)
    }));
  };

  const handleAddToCart = (item: MenuItem) => {
    const quantity = quantities[item.id] || 1;
    onAddToCart(item, quantity);
    setQuantities(prev => ({ ...prev, [item.id]: 1 }));
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <h1>Cardápio de Cuscuz</h1>
        <p className="text-muted-foreground mt-2">
          Cuscuz nordestino tradicional, feito com amor e ingredientes selecionados
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {menuItems.map((item) => (
          <div
            key={item.id}
            className="border border-border rounded-lg p-6 bg-card hover:shadow-lg transition-shadow"
          >
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <h3>{item.size}</h3>
                <span className="text-muted-foreground">{item.weight}</span>
              </div>
              <p className="text-muted-foreground">{item.description}</p>
            </div>

            <div className="mb-4">
              <p className="text-2xl text-primary">
                R$ {item.price.toFixed(2)}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center border border-border rounded">
                <button
                  onClick={() => handleQuantityChange(item.id, (quantities[item.id] || 1) - 1)}
                  className="px-3 py-1 hover:bg-muted"
                >
                  -
                </button>
                <input
                  type="number"
                  min="1"
                  value={quantities[item.id] || 1}
                  onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value) || 1)}
                  className="w-12 text-center border-x border-border bg-transparent"
                />
                <button
                  onClick={() => handleQuantityChange(item.id, (quantities[item.id] || 1) + 1)}
                  className="px-3 py-1 hover:bg-muted"
                >
                  +
                </button>
              </div>

              <button
                onClick={() => handleAddToCart(item)}
                className="flex-1 bg-primary text-primary-foreground px-4 py-2 rounded hover:opacity-90 flex items-center justify-center gap-2"
              >
                <ShoppingCart size={16} />
                Adicionar
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
