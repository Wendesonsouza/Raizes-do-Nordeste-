import { useState } from 'react';
import { UserPlus, Users as UsersIcon, Shield } from 'lucide-react';

export interface Client {
  id: string;
  name: string;
  phone: string;
  address: string;
  area: string;
  isAdmin: boolean;
  createdAt: string;
}

interface ClientRegistrationProps {
  onAddClient: (client: Omit<Client, 'id' | 'createdAt'>) => void;
  clients: Client[];
}

export function ClientRegistration({ onAddClient, clients }: ClientRegistrationProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    area: '',
    isAdmin: false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.phone) {
      onAddClient(formData);
      setFormData({ name: '', phone: '', address: '', area: '', isAdmin: false });
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const value = e.target.type === 'checkbox' ? (e.target as HTMLInputElement).checked : e.target.value;
    setFormData(prev => ({
      ...prev,
      [e.target.name]: value
    }));
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <div className="mb-6">
            <h1>Cadastro de Clientes</h1>
            <p className="text-muted-foreground mt-2">
              Registre novos clientes para melhor atendimento
            </p>
          </div>

          <form onSubmit={handleSubmit} className="border border-border rounded-lg p-6 bg-card">
            <div className="mb-4">
              <label htmlFor="name" className="block mb-2">
                Nome Completo *
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-border rounded bg-input-background"
                placeholder="Digite o nome do cliente"
              />
            </div>

            <div className="mb-4">
              <label htmlFor="phone" className="block mb-2">
                Telefone *
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-border rounded bg-input-background"
                placeholder="(00) 00000-0000"
              />
            </div>

            <div className="mb-4">
              <label htmlFor="address" className="block mb-2">
                Endereço
              </label>
              <textarea
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                rows={2}
                className="w-full px-4 py-2 border border-border rounded bg-input-background"
                placeholder="Rua, número, bairro"
              />
            </div>

            <div className="mb-4">
              <label htmlFor="area" className="block mb-2">
                Área/Região *
              </label>
              <select
                id="area"
                name="area"
                value={formData.area}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-border rounded bg-input-background"
              >
                <option value="">Selecione a área</option>
                <option value="Centro">Centro</option>
                <option value="Zona Norte">Zona Norte</option>
                <option value="Zona Sul">Zona Sul</option>
                <option value="Zona Leste">Zona Leste</option>
                <option value="Zona Oeste">Zona Oeste</option>
                <option value="Periferia">Periferia</option>
                <option value="Outra">Outra</option>
              </select>
            </div>

            <div className="mb-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  name="isAdmin"
                  checked={formData.isAdmin}
                  onChange={handleChange}
                  className="w-4 h-4 border border-border rounded"
                />
                <span className="flex items-center gap-2">
                  <Shield size={16} className="text-primary" />
                  Cadastrar como Administrador
                </span>
              </label>
            </div>

            <button
              type="submit"
              className="w-full bg-primary text-primary-foreground px-4 py-3 rounded hover:opacity-90 flex items-center justify-center gap-2"
            >
              <UserPlus size={18} />
              Cadastrar Cliente
            </button>
          </form>
        </div>

        <div>
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2>Clientes Cadastrados</h2>
              <p className="text-muted-foreground mt-1">
                Total: {clients.length} cliente{clients.length !== 1 ? 's' : ''}
              </p>
            </div>
            <UsersIcon size={32} className="text-muted-foreground" />
          </div>

          <div className="space-y-4 max-h-[600px] overflow-y-auto">
            {clients.length === 0 ? (
              <div className="border border-border rounded-lg p-8 bg-card text-center">
                <UsersIcon size={48} className="mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">
                  Nenhum cliente cadastrado ainda
                </p>
              </div>
            ) : (
              clients.map((client) => (
                <div
                  key={client.id}
                  className="border border-border rounded-lg p-4 bg-card hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4>{client.name}</h4>
                    {client.isAdmin && (
                      <span className="flex items-center gap-1 px-2 py-1 bg-primary text-primary-foreground rounded text-sm">
                        <Shield size={14} />
                        Admin
                      </span>
                    )}
                  </div>
                  <p className="text-muted-foreground mt-1">
                    📱 {client.phone}
                  </p>
                  {client.area && (
                    <p className="text-muted-foreground mt-1">
                      🗺️ {client.area}
                    </p>
                  )}
                  {client.address && (
                    <p className="text-muted-foreground mt-1">
                      📍 {client.address}
                    </p>
                  )}
                  <p className="text-muted-foreground mt-2">
                    Cadastro: {new Date(client.createdAt).toLocaleDateString('pt-BR')}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
