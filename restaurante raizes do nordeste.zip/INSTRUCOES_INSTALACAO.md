# Raízes do Sertão - Aplicativo de Restaurante

## 📋 Pré-requisitos

- Node.js (versão 16 ou superior)
- npm, yarn ou pnpm

## 🚀 Como instalar e rodar

### 1. Criar o projeto React com Vite

```bash
# Criar novo projeto
npm create vite@latest raizes-do-sertao -- --template react-ts

# Ou se preferir JavaScript puro:
npm create vite@latest raizes-do-sertao -- --template react

# Entrar na pasta
cd raizes-do-sertao
```

### 2. Instalar Tailwind CSS

```bash
# Instalar dependências do Tailwind
npm install -D tailwindcss postcss autoprefixer

# Inicializar Tailwind
npx tailwindcss init -p
```

### 3. Configurar Tailwind

Edite o arquivo `tailwind.config.js`:

```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

### 4. Configurar CSS do Tailwind

Edite o arquivo `src/index.css`:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### 5. Instalar ícones Lucide React

```bash
npm install lucide-react
```

### 6. Copiar os arquivos do projeto

Copie os seguintes arquivos para as respectivas pastas:

```
src/
├── app/
│   ├── App.tsx
│   └── components/
│       ├── MenuSection.tsx
│       ├── ClientRegistration.tsx
│       └── ManagementPanel.tsx
```

### 7. Atualizar o main.tsx ou main.jsx

Edite `src/main.tsx` (ou `main.jsx`):

```typescript
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './app/App'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
```

### 8. Rodar o projeto

```bash
# Instalar dependências
npm install

# Rodar em modo desenvolvimento
npm run dev
```

O aplicativo estará disponível em `http://localhost:5173`

## 📦 Estrutura do Projeto

```
raizes-do-sertao/
├── src/
│   ├── app/
│   │   ├── App.tsx              # Componente principal
│   │   └── components/
│   │       ├── MenuSection.tsx          # Cardápio de cuscuz
│   │       ├── ClientRegistration.tsx   # Cadastro de clientes
│   │       └── ManagementPanel.tsx      # Painel administrativo
│   ├── index.css                # Estilos globais + Tailwind
│   └── main.tsx                 # Entry point
├── public/                      # Arquivos estáticos
├── package.json
└── vite.config.ts
```

## 🔧 Scripts disponíveis

```bash
npm run dev      # Roda em modo desenvolvimento
npm run build    # Cria build de produção
npm run preview  # Preview do build de produção
```

## 📱 Funcionalidades

### ✅ Cardápio
- 4 tamanhos de cuscuz (Pequeno 150g, Médio 300g, Grande 500g, Família 1kg)
- Seleção de quantidade
- Adicionar ao carrinho

### ✅ Cadastro de Clientes
- Nome completo
- Telefone
- Endereço
- Lista de clientes cadastrados

### ✅ Painel de Gerenciamento
- Métricas (total de clientes, pedidos pendentes/finalizados, receita)
- Lista de pedidos recentes
- Lista completa de clientes

## 💾 Persistência de Dados

**Importante:** A versão atual usa apenas estado local (memória). Os dados são perdidos ao recarregar a página.

Para ter persistência real, você pode:

### Opção 1: LocalStorage (simples)
Adicione ao `App.tsx`:

```typescript
// Salvar no localStorage
useEffect(() => {
  localStorage.setItem('clients', JSON.stringify(clients));
  localStorage.setItem('orders', JSON.stringify(orders));
}, [clients, orders]);

// Carregar do localStorage
useEffect(() => {
  const savedClients = localStorage.getItem('clients');
  const savedOrders = localStorage.getItem('orders');

  if (savedClients) setClients(JSON.parse(savedClients));
  if (savedOrders) setOrders(JSON.parse(savedOrders));
}, []);
```

### Opção 2: Banco de Dados (Supabase, Firebase, etc.)
Use o arquivo `database-schema.sql` incluído no projeto como referência para criar as tabelas.

## 🎨 Personalização

Para mudar cores e temas, edite as classes Tailwind nos componentes ou configure o `tailwind.config.js`.

## 📝 Notas

- Este é um projeto educacional/demonstrativo
- Não inclui autenticação de usuários
- Não tem integração com sistema de pagamento
- Os dados são apenas locais (memória do navegador)

## 🆘 Problemas Comuns

### Erro: "Module not found"
```bash
npm install
```

### Porta já em uso
```bash
# Usar outra porta
npm run dev -- --port 3000
```

### Tailwind não funciona
Verifique se o `index.css` tem as diretivas @tailwind e se está importado no `main.tsx`

## 📧 Suporte

Para dúvidas ou problemas, consulte a documentação:
- [Vite](https://vitejs.dev/)
- [React](https://react.dev/)
- [Tailwind CSS](https://tailwindcss.com/)
- [Lucide Icons](https://lucide.dev/)
