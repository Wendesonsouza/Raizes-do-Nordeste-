
  # restaurante raizes do nordeste

  This is a code bundle for restaurante raizes do nordeste. The original project is available at https://www.figma.com/design/sfx8Ro3ITMYNIYFUW9mWVp/restaurante-raizes-do-nordeste.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  