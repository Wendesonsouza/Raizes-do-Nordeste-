-- Schema SQL para o Restaurante Raízes do Sertão
-- Este arquivo mostra como seria a estrutura do banco de dados

-- Tabela de Clientes
CREATE TABLE clientes (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    endereco TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Pedidos
CREATE TABLE pedidos (
    id SERIAL PRIMARY KEY,
    cliente_id INTEGER REFERENCES clientes(id),
    nome_cliente VARCHAR(100) NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Itens do Cardápio
CREATE TABLE cardapio (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    tamanho VARCHAR(50) NOT NULL,
    peso VARCHAR(20),
    preco DECIMAL(10, 2) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(50) DEFAULT 'cuscuz'
);

-- Tabela de Itens do Pedido
CREATE TABLE itens_pedido (
    id SERIAL PRIMARY KEY,
    pedido_id INTEGER REFERENCES pedidos(id) ON DELETE CASCADE,
    nome_item VARCHAR(100) NOT NULL,
    quantidade INTEGER NOT NULL,
    preco_unitario DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL
);

-- Inserir itens do cardápio (cuscuz)
INSERT INTO cardapio (nome, tamanho, peso, preco, descricao) VALUES
    ('Cuscuz Pequeno', 'Pequeno', '150g', 8.90, 'Perfeito para um lanche rápido'),
    ('Cuscuz Médio', 'Médio', '300g', 15.90, 'Porção individual ideal'),
    ('Cuscuz Grande', 'Grande', '500g', 24.90, 'Para quem tem bom apetite'),
    ('Cuscuz Família', 'Família', '1kg', 42.90, 'Serve até 4 pessoas');

-- Índices para melhorar performance
CREATE INDEX idx_pedidos_cliente ON pedidos(cliente_id);
CREATE INDEX idx_pedidos_data ON pedidos(data_pedido);
CREATE INDEX idx_pedidos_status ON pedidos(status);
CREATE INDEX idx_itens_pedido ON itens_pedido(pedido_id);

-- Exemplos de consultas úteis:

-- Buscar todos os clientes
-- SELECT * FROM clientes ORDER BY created_at DESC;

-- Buscar pedidos de um cliente específico
-- SELECT p.*, c.nome, c.telefone
-- FROM pedidos p
-- JOIN clientes c ON p.cliente_id = c.id
-- WHERE c.id = 1;

-- Total de vendas do dia
-- SELECT SUM(total) as receita_dia
-- FROM pedidos
-- WHERE DATE(data_pedido) = CURRENT_DATE;

-- Itens mais vendidos
-- SELECT nome_item, SUM(quantidade) as total_vendido
-- FROM itens_pedido
-- GROUP BY nome_item
-- ORDER BY total_vendido DESC;

-- Pedidos pendentes
-- SELECT * FROM pedidos WHERE status = 'pending';

-- Histórico completo de um pedido
-- SELECT p.id, p.total, p.data_pedido,
--        i.nome_item, i.quantidade, i.preco_unitario
-- FROM pedidos p
-- JOIN itens_pedido i ON p.id = i.pedido_id
-- WHERE p.id = 1;
